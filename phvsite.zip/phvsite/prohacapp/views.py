from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import redirect
from django.contrib.auth import authenticate, login, logout
from .models import US_STATES, US_CITIES, User, Lawyer
from django.conf import settings
from django.core.files.storage import FileSystemStorage
import stripe
import os

stripe.api_key = settings.STRIPE_KEY
# Create your views here.

def logoutUser(request):
    print("****we are here")
    logout(request) 
    return redirect('/')

def success(request):
    current_user = request.user

    checkout_session_id = request.GET.get('session_id','')
    checkout_session = stripe.checkout.Session.retrieve(checkout_session_id)
    
    customer=checkout_session.customer

    lawyerUser = Lawyer.objects.get(owner=current_user)
    lawyerUser.customer_id = customer
    if checkout_session.payment_status == "paid":
        lawyerUser.payment_status = 1
    else:
        lawyerUser.payment_status = 0
    
    try:
        lawyerUser.save()
        return render(request,'success.html')

    except Exception as e:
        print(e)

    
    #mark user as paid in lawyers

def index(request):
    States = US_STATES.objects.all()
    context = {
        'state_list' : States
    }
    return render(request,'index.html',context)

def promote(request):
    States = US_STATES.objects.all()
    context = {
        'state_list' : States
    }

    return render(request,'promote.html',context)

def cancel(request):
    pass



def editProfile(request):
    current_user = request.user
    lawyerUser = Lawyer.objects.get(owner=current_user)
    States = US_STATES.objects.all()
    context = {
        'user' : current_user,
        'lawyer': lawyerUser,
        'state_list' : States
    }
    return render(request,'edit_profile.html',context)

def updateProfile(request):
    current_user = request.user
    lawyerUser = Lawyer.objects.get(owner=current_user)
    if request.method == 'POST':    
        lawyerUser.description = request.POST.get('firmDescription`','')
        lawyerUser.firm_name = request.POST.get('firm_name','')
        lawyerUser.firm_phone = request.POST.get('firm_phone','')
        lawyerUser.firm_street = request.POST.get('firm_street','')
        lawyerUser.firm_street2 = request.POST.get('firm_street2','')
        lawyerUser.firm_city = request.POST.get('firm_city')
        if request.FILES.get('upload'):
            upload = request.FILES.get('upload')
            fss = FileSystemStorage()
            file = fss.save(upload.name, upload)
            file_url = fss.url(file)
            lawyerUser.image_url = file_url
        lawyerUser.save()
    return redirect('/profile/edit')

def signupStepOne(request):
    fullNamePost = request.POST.get('fullName','')
    fullName = fullNamePost.split()
    first_name = fullName[0]
    last_name = fullName [1]
    password = request.POST.get('password','')
    email = request.POST.get('email','')
    state = request.POST.get('state')
    price_id = 'price_1JmSIJE7N9kUtQpWEs32REpx'
    State = US_STATES.objects.filter(STATE_CODE=str(state))
    #register user - mark payment pending
    try: 
        user = User.objects.create_user(email, email, password)
        user.first_name = first_name
        user.last_name = last_name
        user.save()
        loginUser = authenticate(request, username=email, password=password)
        if user is not None:
            login(request, loginUser)
            # Redirect to a success page.
            try:
                lawyer = Lawyer(owner=user,state=State[0])
                lawyer.save()
                try:
                    checkout_session = stripe.checkout.Session.create(
                        payment_method_types=['card'],
                        line_items=[
                            {
                                'price': price_id,
                                'quantity': 1,
                            },
                        ],
                        mode='subscription',
                        success_url= settings.SITE_URL +
                        'success?session_id={CHECKOUT_SESSION_ID}',
                        cancel_url= settings.SITE_URL + '/cancel.html',
                        customer_email =  email,
                    )
                    return redirect(checkout_session.url, code=303)
                except Exception as e:
                    print(e)
                    return "Server error", 500
            except Exception as e:
                print(e)
        else:
            # Return an 'invalid login' error message.
            print('invalid login')      
    except Exception as e:
        print(e)

def lookup(request):

    searchValue = request.POST.get('search', '')
    print(searchValue)

    ## check state if state return state view data
    State = US_STATES.objects.filter(STATE_NAME=str(searchValue))
    if len(State) > 0:
        returnState = State[0]
        context = {
            'state': returnState,
            'attorneys': 'list of attorneys goes here'
        }
        return redirect('/state/'+returnState.STATE_NAME)
    else:
        returnState = None

    ## check city if city return city view data

    # check zipcode if zipcode reutnr zipcode view data

def stateResults(request, state):
    State = US_STATES.objects.filter(STATE_NAME=str(state))
    
    if len(State) > 0:
        returnState = State[0]
        cities = US_CITIES.objects.all().filter(ID_STATE_id = returnState.id)
        context = {
            'state': returnState,
            'state_id':returnState.id,
            'city_list': cities,
            'attorneys': 'list of attorneys goes here',
            'faq': 'list of faq goes here',
            'federal_districts': 'list of federal district names and urls goes here',
            'bankrupcy_districts':'list of bankrupcy district names and urls goes here'
        }
        return render(request, 'results.html', context)
    else:
        returnState = None

def stripe_webhook(request):
    stripe.api_key = settings.STRIPE_KEY
    endpoint_secret = settings.STRIPE_ENDPOINT_SECRET
    payload = request.body
    sig_header = request.META['HTTP_STRIPE_SIGNATURE']
    event = None

    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, endpoint_secret
        )
    except ValueError as e:
        # Invalid payload
        return HttpResponse(status=400)
    except stripe.error.SignatureVerificationError as e:
        # Invalid signature
        return HttpResponse(status=400)

    # Handle the checkout.session.completed event
    if event['type'] == 'checkout.session.completed':
        print("Payment was successful.")
        #mark payment status paid
        # TODO: run some custom code here
    elif event['type'] == 'customer.subscription.created':
        print("Customer subscription successful")
        print("***PRINTING WEB HOOK EVENT")
        print(event)
        print("PRINTING WEB HOOK EVENT***")
    elif event['type'] =='customer.subscription.updated':
        print("Customer subscription updated")
    elif event['type'] == 'customer.subscription.deleted':
        print("customer subscription failed")
    return HttpResponse(status=200)

def loginPage(request):
    return render(request,'login.html')


    

def authPage(request):
    password = request.POST.get('password','')
    email = request.POST.get('email','')
    user = authenticate(request, username=email, password=password)
    if user is not None:
        login(request, user)
        #if login successsful redirect to dashboard
        return redirect('/profile/edit')
    else:
        return redirect('/')