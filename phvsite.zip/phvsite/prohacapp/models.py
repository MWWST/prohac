from django.db import models
from django import utils
from django.contrib.auth.models import User # new
from datetime import datetime

# Create your models here.
class US_STATES(models.Model):
    STATE_CODE = models.CharField(max_length=2)
    STATE_NAME = models.CharField(max_length=255)
    import_id = models.IntegerField(default=000)
    created_at = models.DateTimeField(default=utils.timezone.now)
    updated_at = models.DateTimeField(default=utils.timezone.now)


    class Meta:
        ordering = ['STATE_NAME']

class US_CITIES(models.Model):
    import_id = models.IntegerField(default=000)
    CITY = models.CharField(max_length=50)
    ID_STATE_id = models.ForeignKey(US_STATES, on_delete=models.CASCADE)
    COUNTY = models.CharField(max_length=50)
    LATITUDE = models.FloatField()
    LONGITUDE = models.FloatField()
    created_at = models.DateTimeField(default=utils.timezone.now)
    updated_at = models.DateTimeField(utils.timezone.now)

class Lawyer(models.Model):
    owner = models.ForeignKey(User, on_delete=models.CASCADE) # new
    state = models.ForeignKey(US_STATES, on_delete=models.CASCADE,default=1) # new
    firm_name = models.CharField(max_length=255)
    firm_phone = models.CharField(max_length=12)
    firm_street = models.CharField(max_length=255)
    firm_street2 = models.CharField(max_length=255)
    firm_city = models.CharField(max_length=50)
    firm_email=models.CharField(max_length=255)
    customer_id = models.CharField(max_length=255)
    description = models.TextField(max_length=1000)
    image_url =models.TextField(max_length=255)
    payment_status=models.IntegerField(default=0)
    class Meta:
        ordering = ['firm_name']
    def __str__(self):
        return self.owner.username
    search_fields = ['owner.username']