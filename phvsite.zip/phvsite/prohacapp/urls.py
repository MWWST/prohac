from django.urls import path
from django.conf import settings
from django.conf.urls.static import static

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('promote',views.promote,name='promote'),
    path('search',views.lookup,name='lookup'),
    path('promote/signup',views.signupStepOne, name='signupStepOne'),
    path('cancel',views.cancel,name='cancel'),
    path('success', views.success,name='success'),
    path('profile/edit',views.editProfile,name='editProfile'),
    path('profile/update',views.updateProfile,name='updateProfile'),
    path('state/<str:state>',views.stateResults,name='stateResults'),
    path('srtipe/webook',views.stripe_webhook,name='stripe_webhook'),
    path('logout',views.logoutUser,name='logoutUser'),
    # path('message/send/<str:user>',views.sendMessage,name='sendMessage'),
    # path('messages/all',views.readMessages,name='readMessages'),
    # path('message/<str:msgID>',views.readOneMessage,name='readOneMessage'),
    # path('message/archive/<str:msgID',views.archiveOneMessage,name='archiveOneMessage'),
    # path('message/markAllRead/<str:user>',views.archiveAllMessages,name='archiveAllMessages')
  

]  + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)